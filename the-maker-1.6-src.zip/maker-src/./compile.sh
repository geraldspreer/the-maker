#!/bin/bash
rm -rf build dist
python2.7 setup_app_store.py py2app --iconfile system/maker.icns --site-packages -r system

echo "------------------------------------"
echo "build done..."
echo "------------------------------------"
echo
echo "tweaking..."
echo "------------------------------------"
echo

cp CHANGES dist
cp LICENSE dist
cp Entitlements.plist dist/TheMaker.app/Contents/TheMaker.entitlements
cp Entitlements.plist dist/TheMaker.app/Contents/MacOS/python.entitlements


echo "Copying patched wxWidgets dylib..."
rm -f dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0.dylib
cp -v lib/libwx_osx_cocoau-2.9.4.0.0.dylib dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0-fix.dylib 

echo "Stripping universal dylib of ppc7400 architecture..."

lipo -remove ppc7400  dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0-fix.dylib -output dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0.dylib 
rm  dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0-fix.dylib 

echo "Checking file..."
echo "File is:"
file dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0.dylib

echo "------------------------------------"
echo "Creating needed symlinks..."
pushd .
cd dist/TheMaker.app/Contents/Frameworks/Python.framework/
sudo ln -s 'Versions/2.7/Python' 'Python'
sudo ln -sf 'Versions/Current/Python' 'Python'
sudo ln -s 'Versions/Current/Resources' 'Resources'

popd

echo "------------------------------------"
echo "Code signing..."

echo "Libraries..."
codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app/Contents/MacOS/python
codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app/Contents/Frameworks/libwx_osx_cocoau-2.9.4.0.0.dylib
codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app/Contents/Frameworks/Python.framework/Versions/2.7/Python
codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app/Contents/Resources/lib/python2.7/lib-dynload/*.so 
codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app/Contents/Resources/lib/python2.7/lib-dynload/wx/*.so 

codesign -f -v -s  "3rd Party Mac Developer Application: Gerald Spreer" dist/TheMaker.app

echo "Sandbox..."
codesign -s "3rd Party Mac Developer Application: Gerald Spreer" -f -v --entitlements dist/TheMaker.app/Contents/TheMaker.entitlements  dist/TheMaker.app/
codesign -s "3rd Party Mac Developer Application: Gerald Spreer" -f -v --entitlements dist/TheMaker.app/Contents/TheMaker.entitlements  dist/TheMaker.app/Contents/MacOS/python


echo "------------------------------------"
echo "Building product..."
productbuild --component "dist/TheMaker.app" /Applications --sign "3rd Party Mac Developer Installer: Gerald Spreer" "TheMaker.pkg"
echo
echo "------------------------------------"
echo "Testing Installer..."
rm -rf dist/
echo "Installing..."
sudo installer -store -pkg "TheMaker.pkg" -target /
echo "Verifying product..."
codesign -v --verbose /Applications/TheMaker.app/
echo "------------------------------------"
echo "resetting sanbox container..."
asctl container acl update -file /Applications/TheMaker.app/
echo "finished..."
