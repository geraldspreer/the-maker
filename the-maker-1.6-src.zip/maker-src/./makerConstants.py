class Constants:
    PROJECTBASE = 'makerProjects'
    LASTPROJECT = 'lastProject.txt'
    MAX_PASS_ATTEMPTS = 3
