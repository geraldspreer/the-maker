def getCopyright():
    
    copyright  = """-------------------------------------------------------------------------------
the maker - Content Management System
-------------------------------------------------------------------------------
Copyright (c) 2006 - 2012, the makerProject

developers:
Gerald Spreer, Brinick Simmons, Ian Barrow

-------------------------------------------------------------------------------
The maker is a CMS for websites. You use it on your Mac and after you 
made your changes you publish to your webhosting service via FTP. 

We hope you enjoy using this application as much as we do.

The possibilities are endless.

-------------------------------------------------------------------------------

Visit http://www.makercms.org for more information.

"""
    return copyright
