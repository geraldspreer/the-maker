import webbrowser as webView

def report():
    webView.open('http://sourceforge.net/tracker/?func=add&group_id=167680&atid=843919')
